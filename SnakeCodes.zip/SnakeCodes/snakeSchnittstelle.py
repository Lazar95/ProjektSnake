#!/usr/bin/env python3

import tkinter as tk # Importieren Modul tkinter damit GUI erstellt werden kann 
import socket as so # Importieren Modul socket damit Wlan Verbindung hergestellt werden kann

class Arduino(object):
    def __init__(self, window, host, port, on_received):
        # initialising (Verbindung zwischen Arduino und Python wird erstellt, Socket wird eingerichtet und anschließend abgerufen)

        self.window = window #GUI wird erstellt
        self.on_received = on_received 

        # Arduino Socket wird geöffnet und mit Arduino verbunden
        self.socket = so.socket()
        self.socket.connect((host, port))
        self.socket.setblocking(False)

		# Buffer wird gelesen 
        self.read_buffer = bytes()

        self._periodic_socket_check()

    def close(self):
        # Verbindung wird getrennt
        self.socket.close()

    def _periodic_socket_check(self):
	# Socket wird periodisch für Werte überprüft
        try:
			# Buffer wird geprüft und Werte werden gelesen
            message = self.socket.recv(1024) #Werte werden empfangen

            if not message:
                raise(IOError('Connection successfully closed')) #Wenn es einen Fehler gibt wird der Text ausgegeben

			# Neuer Wert wird zum Buffer hinzugefügt
            self.read_buffer+= message

        except so.error: # Wenn Bedingung vorher nicht klappt wird except durchgeführt
            pass

		# Buffer wird gelesen und der String wird verarbeitet
        while b'\n' in self.read_buffer:
            score, self.read_buffer = self.read_buffer.split(b'\n')

            score = score.decode('utf-8').strip()
            self.on_received(score)

class SnakeWindow(object): # GUI Inhalt wird erstellt
    def __init__(self):
        # Leere GUI wird eingerichtet
        self.setup_window()

		# Verbindung mit dem Wlan Shield
        host = input('Bitte, Hostname eingeben: ')
        port = input('Bitte, Port eingeben: ')

		# Verbindung zu Arduino wird hergestellt
        self.arduino = Arduino(self.window, host, int(port), self.on_received)

        self.setup_content()

    def on_received(self, score): # Die Werte werden dynamisch empfangen und werden im richtigen Format hinzugefügt
		self.btn_label_var.set('Score ist: {}'.format(score))

    def setup_window(self): # GUI wird mithilfe vom Modul tkinter erstellt (Initialisierung)
        self.window = tk.Tk()
        self.window.title('SNAKE')
        self.window.protocol("WM_DELETE_WINDOW", self.on_close)

    def on_close(self): # Methode wird aufgerufen wenn das GUI geschlossen wird
        self.arduino.close()
        self.window.destroy() #Der Speicherort wird geleert

    def setup_content(self): #Labels werden erstellt und Score wird hinzugefügt
	    self.score_var = tk.StringVar(self.window)
        self.score_var.set('Score : 0')
		
		self.score = tk.Text(self.window, height = 5, width = 10) # Aussehen vom GUI
		self.score.grid(row = 1, column = 1) # Beide labels werden im Tabellenformat angezeigt
		self.score.insert(tk.END, "score") #Text = Score
		
		self.score_label = tk.Text(self.window, height = 5, width = 10) 
		self.score_label.grid(row = 1, column = 2)
		self.score_label.insert(tk.END, self.score_var) #Score von Arduino wird empfangen und ausgegeben

    def run(self):
        # GUI wird durchgeführt 

        self.window.mainloop()

# Beide Befehle werden immer durchgeführt damit die GUI nicht geschlossen wird
window = SnakeWindow()
window.run()
