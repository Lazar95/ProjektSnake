var searchData=
[
  ['snakewindow',['SnakeWindow',['../classsnake_schnittstelle_1_1_snake_window.html',1,'snakeSchnittstelle']]]
];
